# AI Tools Hub

A modern, futuristic, mobile-responsive AI tools directory built with plain HTML, CSS and JavaScript.

## Files

- `index.html` — page structure
- `style.css` — futuristic responsive design
- `script.js` — tool data, search and category filtering

## Publish on GitHub Pages

Create a public repository, upload these three files to the repository root, then go to:

**Settings → Pages → Build and deployment → Source → Deploy from a branch**

Choose `main` and `/(root)`, then Save.

Your site will be available from the GitHub Pages URL shown in Settings → Pages.

## Customize

Edit the `tools` array in `script.js` to add or remove tools.

Each tool has:
- `name`
- `category`
- `icon`
- `pricing`
- `description`
- `url`
