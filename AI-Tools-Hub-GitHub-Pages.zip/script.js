const tools = [
  { name: "ChatGPT", category: "Chat", icon: "✦", pricing: "Free plan", description: "AI assistant for writing, brainstorming, learning, coding and everyday tasks.", url: "https://chatgpt.com/" },
  { name: "Claude", category: "Chat", icon: "◈", pricing: "Free plan", description: "AI assistant for analysis, writing, coding and working with long documents.", url: "https://claude.ai/" },
  { name: "Gemini", category: "Chat", icon: "✦", pricing: "Free plan", description: "Google's AI assistant for questions, ideas, writing and multimodal tasks.", url: "https://gemini.google.com/" },
  { name: "Perplexity", category: "Research", icon: "⌕", pricing: "Free plan", description: "AI-powered search and research with answers and cited web sources.", url: "https://www.perplexity.ai/" },
  { name: "Canva AI", category: "Image", icon: "◉", pricing: "Free plan", description: "Create designs and visual content with AI-powered creative features.", url: "https://www.canva.com/ai/" },
  { name: "Adobe Firefly", category: "Image", icon: "✺", pricing: "Free tier", description: "Generate and edit images and creative assets using generative AI.", url: "https://firefly.adobe.com/" },
  { name: "Runway", category: "Video", icon: "▶", pricing: "Free tier", description: "AI creative tools for generating and editing video and visual content.", url: "https://runwayml.com/" },
  { name: "ElevenLabs", category: "Audio", icon: "♫", pricing: "Free tier", description: "AI voice generation, text-to-speech and voice-focused creative tools.", url: "https://elevenlabs.io/" },
  { name: "GitHub Copilot", category: "Coding", icon: "</>", pricing: "Free plan", description: "AI coding assistance for writing, explaining and completing code.", url: "https://github.com/features/copilot" },
  { name: "Notion AI", category: "Productivity", icon: "N", pricing: "Limited free", description: "AI features for notes, documents, summaries and workspace productivity.", url: "https://www.notion.com/product/ai" },
  { name: "Grammarly", category: "Writing", icon: "G", pricing: "Free plan", description: "AI writing assistance for clarity, grammar, rewriting and tone.", url: "https://www.grammarly.com/" },
  { name: "Khanmigo", category: "Study", icon: "K", pricing: "Free/limited", description: "AI learning support from Khan Academy for studying and tutoring.", url: "https://www.khanmigo.ai/" }
];

const categories = [
  ["All", "✦", "All tools"],
  ["Chat", "◌", "Chat & assistants"],
  ["Writing", "✎", "Writing tools"],
  ["Image", "▧", "Image generation"],
  ["Video", "▶", "Video tools"],
  ["Audio", "♫", "Voice & audio"],
  ["Coding", "</>", "Developer tools"],
  ["Study", "⌘", "Learning tools"],
  ["Productivity", "⚡", "Get more done"]
];

const grid = document.getElementById("toolGrid");
const searchInput = document.getElementById("searchInput");
const categoryBar = document.getElementById("categoryBar");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const toolCount = document.getElementById("toolCount");
let activeCategory = "All";

function renderCategories() {
  categoryBar.innerHTML = categories.map(([name, icon, sub]) => `
    <button class="category-btn ${name === activeCategory ? "active" : ""}" data-category="${name}">
      <span class="category-icon">${icon}</span>
      <span><strong>${name}</strong><small>${sub}</small></span>
    </button>
  `).join("");
}

function getFilteredTools() {
  const query = searchInput.value.trim().toLowerCase();
  return tools.filter(tool => {
    const matchesCategory = activeCategory === "All" || tool.category === activeCategory;
    const haystack = `${tool.name} ${tool.category} ${tool.description}`.toLowerCase();
    return matchesCategory && haystack.includes(query);
  });
}

function renderTools() {
  const filtered = getFilteredTools();
  resultCount.textContent = `${filtered.length} tool${filtered.length === 1 ? "" : "s"}`;
  emptyState.classList.toggle("hidden", filtered.length !== 0);
  grid.classList.toggle("hidden", filtered.length === 0);

  grid.innerHTML = filtered.map(tool => `
    <article class="tool-card">
      <div class="card-top">
        <div class="tool-logo">${tool.icon}</div>
        <span class="tag">${tool.category}</span>
      </div>
      <h3>${tool.name}</h3>
      <p>${tool.description}</p>
      <div class="card-bottom">
        <span class="pricing">${tool.pricing}</span>
        <a class="visit" href="${tool.url}" target="_blank" rel="noopener noreferrer">Try tool ↗</a>
      </div>
    </article>
  `).join("");
}

function selectCategory(category) {
  activeCategory = category;
  renderCategories();
  renderTools();
  document.getElementById("tools").scrollIntoView({ behavior: "smooth", block: "start" });
}

categoryBar.addEventListener("click", e => {
  const button = e.target.closest("[data-category]");
  if (button) selectCategory(button.dataset.category);
});

searchInput.addEventListener("input", renderTools);

document.getElementById("clearFilters").addEventListener("click", () => {
  activeCategory = "All";
  searchInput.value = "";
  renderCategories();
  renderTools();
});

document.getElementById("resetSearch").addEventListener("click", () => {
  activeCategory = "All";
  searchInput.value = "";
  renderCategories();
  renderTools();
});

document.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    searchInput.focus();
  }
});

toolCount.textContent = tools.length;
document.getElementById("year").textContent = new Date().getFullYear();
renderCategories();
renderTools();
